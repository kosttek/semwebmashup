semwebmashup
============

dokuwiki plugin semantic web mashup
