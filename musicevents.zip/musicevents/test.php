<?php
$name = "name";
echo "lol\"".$name."\"adsd
asd";
?>